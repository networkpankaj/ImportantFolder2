export type Package = {
  sNo: string;
  departmentName: string;
  // invoiceDate: string;
  status: string;
};
