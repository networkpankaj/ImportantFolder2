import DefaultLayout from '../../layout/DefaultLayout';

const ShiftTiming = () => {
    return (

        <DefaultLayout>
            <div>Hello From ShiftTiming</div>
        </DefaultLayout>
    )

}


export default ShiftTiming;