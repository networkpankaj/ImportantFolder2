import DefaultLayout from '../../layout/DefaultLayout';

const LeaveType = () => {
    return (

        <DefaultLayout>
            <div>Hello From LeaveType</div>
        </DefaultLayout>
    )

}


export default LeaveType;