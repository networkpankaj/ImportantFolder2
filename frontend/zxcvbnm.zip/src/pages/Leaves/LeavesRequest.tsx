
import DefaultLayout from '../../layout/DefaultLayout'

const LeavesRequest = () => {
  return (
    <DefaultLayout>
    <div>LeavesRequest</div>

    </DefaultLayout>

  )
}

export default LeavesRequest