import React from 'react';
import UserCompany from '../Dashboard/UserCompany';
const UserAdmin = () => {
  return (
    <div>
      <UserCompany />
    </div>
  );
};

export default UserAdmin;
